package secure;

import java.io.*;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.Socket;
import java.util.Map;
import org.apache.commons.codec.binary.Base64;

/**
 * 文件传输Client端
 */
public class FileTransferClient extends Socket {
	
	private static byte[] publicKey1;
	private static byte[] privateKey1;
	private static byte[] key1;
	private static byte[] publicKey2;
 
    private static final String SERVER_IP = "192.168.1.109"; // 服务端IP
    private static final int SERVER_PORT = 8899; // 服务端端口
 
    private Socket client;
 
    private FileInputStream fis;
    private DataInputStream dis;
    private DataOutputStream dos;
 
    /**
     * 构造函数<br/>
     * 与服务器建立连接
     * @throws Exception
     */
    public FileTransferClient() throws Exception {
        super(SERVER_IP, SERVER_PORT);
        this.client = this;
        System.out.println("\nClient[port:" + client.getLocalPort() + "] link start!");
    }
 
    /**
     * 向服务端传输文件
     * @throws Exception
     */
    public void sendFile() throws Exception {
        try {
            String[] cmds = {"/bin/sh","-c","find /home -name lhx.txt 2>/dev/null"};  
            Process pro = Runtime.getRuntime().exec(cmds);  
            pro.waitFor();  
            InputStream in = pro.getInputStream();  
            BufferedReader read = new BufferedReader(new InputStreamReader(in));  
            String line = null;  
            if((line = read.readLine())!=null){  
                System.out.print("target confirmed : ");
                System.out.println(line);
            } else {
                System.out.println("File not found!");
                System.exit(0);
            }
            File file = new File(line);
            if(file.exists()) {
                fis = new FileInputStream(file);
                dos = new DataOutputStream(client.getOutputStream());
                dis = new DataInputStream(client.getInputStream());
        	
                // 文件名
                String filename = file.getName();
                dos.writeUTF(filename);
                dos.flush();
                
                // 开始传输文件
                System.out.println("ready to transfer....");
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                byte[] bytes = new byte[1024];
                int length = 0;
                long progress = 0;
                while((length = fis.read(bytes, 0, bytes.length)) != -1) {
                    dos.write(bytes, 0, length);
                    dos.flush();
                    progress += length;
                    System.out.print("| " + (100*progress/file.length()) + "% |");
                }
                System.out.println("Finished!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if(fis != null)
                fis.close();
            if(dos != null)
                dos.close();
            client.close();
        }
    }
    
    public static void main(String[] args) {
        try {
            FileTransferClient client = new FileTransferClient(); // 启动客户端连接
            client.sendFile(); // 传输文件
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
 
}